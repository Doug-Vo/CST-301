# CST-301
 
# README FILE
# By: Duc Vo, Ty Gehrke, Mahlete Legesse

## VIDEO LINK
    video link: https://youtu.be/TTPIfdPuD-U

## Documemtation

	One executable Python file "AST.py"
	One java file "HelloWorld.java"
    One ouput json file "ast.json"
	
